package com.fse.service;

import java.util.List;

import com.fse.entity.ParentTaskTable;
import com.fse.model.TaskManagerMaster;

public interface TaskManagerService {
	public String addTask(ParentTaskTable ptt);
	
	public List<TaskManagerMaster> getAllTasks();
	
	public List<TaskManagerMaster> suspendTask(TaskManagerMaster taskManagerMaster);
}
