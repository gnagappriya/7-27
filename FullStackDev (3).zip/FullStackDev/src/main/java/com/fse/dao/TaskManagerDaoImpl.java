package com.fse.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fse.entity.ParentTaskTable;
import com.fse.entity.TaskTable;

import com.fse.model.TaskManagerMaster;

@Repository
@Transactional
public class TaskManagerDaoImpl implements TaskManagerDao{

	 @Autowired
	 private SessionFactory sessionFactory;
	@Override
	public String addTask(ParentTaskTable ptt) {
		sessionFactory.getCurrentSession().saveOrUpdate(ptt);
		return ptt.getParenttask();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<TaskManagerMaster> getAllTasks() {
		
		List<ParentTaskTable> pt =sessionFactory.getCurrentSession().createNamedQuery("ParentTaskTable.getAllTasks", ParentTaskTable.class).list();
		List<TaskManagerMaster> taskManagerMasterList = new ArrayList<>();
		for(ParentTaskTable ptt : pt) {
			
			TaskManagerMaster taskManagerMaster = new TaskManagerMaster();
			taskManagerMaster.setParentid(ptt.getParentid());
			taskManagerMaster.setParentTask(ptt.getParenttask());
			for(TaskTable tt: ptt.getTaskTableList()) {
				taskManagerMaster.setTaskid(tt.getTaskid());
				taskManagerMaster.setTask(tt.getTask());
				taskManagerMaster.setPriority(tt.getPriority());
				taskManagerMaster.setStartdate(tt.getStartdate());
				taskManagerMaster.setEnddate(tt.getEnddate());
				taskManagerMaster.setTaskstatus(tt.getTaskstatus());
				taskManagerMasterList.add(taskManagerMaster);
			}
				
		}
		return (List<TaskManagerMaster>) taskManagerMasterList;
		
	}
	@Override
	public List<TaskManagerMaster> suspendTask(TaskManagerMaster taskManagerMaster) {
		Query query =  sessionFactory.getCurrentSession().createQuery(" update TaskTable set taskstatus = :taskstatus where taskid = :taskid ");
		 query.setParameter("taskstatus", taskManagerMaster.getTaskstatus());
		 query.setParameter("taskid", taskManagerMaster.getTaskid());
		 int result = query.executeUpdate();
		
		
		 
		 
		return getAllTasks();
	}

	
}
